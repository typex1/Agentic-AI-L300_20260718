"""Lab environment settings and helpers for running the 06-workshops notebooks in the
"Building and Deploying Intelligent Financial Agents" lab account.

The lab IAM policy only permits:
  * the Bedrock model ``amazon.nova-pro-v1:0``
  * one AgentCore Runtime named ``personal_finance_agent`` (ECR repo / CodeBuild project derived from it)
  * the pre-created Runtime and CodeBuild execution roles (no IAM role creation)
  * one AgentCore Memory named ``FinancialAdvisorMemory`` (memory IDs ``FinancialAdvisorMemory-*``)

Because only a single runtime and a single memory can exist at a time, the notebooks call
``reset_lab_runtime()`` / ``reset_lab_memory()`` before creating their resource. These helpers
DELETE any existing runtime named ``personal_finance_agent`` or memory named
``FinancialAdvisorMemory`` (for example ones left over from a previous notebook).
"""

import os
import time
from pathlib import Path

import boto3
from botocore.exceptions import ClientError

MODEL_ID = "amazon.nova-pro-v1:0"
AGENT_NAME = "personal_finance_agent"
MEMORY_NAME = "FinancialAdvisorMemory"


def get_region():
    """Lab region (the Code Editor sets AWS_DEFAULT_REGION, not AWS_REGION)."""
    return (
        os.environ.get("AWS_REGION")
        or os.environ.get("AWS_DEFAULT_REGION")
        or boto3.Session().region_name
        or "us-east-1"
    )


def get_account_id():
    return boto3.client("sts", region_name=get_region()).get_caller_identity()["Account"]


def runtime_role_arn(region=None):
    region = region or get_region()
    return f"arn:aws:iam::{get_account_id()}:role/AmazonBedrockAgentCoreSDKRuntime-{region}"


def codebuild_role_arn(region=None):
    region = region or get_region()
    return f"arn:aws:iam::{get_account_id()}:role/AmazonBedrockAgentCoreSDKCodeBuild-{region}-5d12c2867b"


# --------------------------------------------------------------------------- runtime
# The lab account enforces BUILD_GENERAL1_SMALL for CodeBuild: projects created/updated with another
# compute type (the starter toolkit uses BUILD_GENERAL1_MEDIUM) are switched to SMALL and their running
# build may be stopped ("CodeBuild failed with status: STOPPED"). Request SMALL up front instead.
LAB_CODEBUILD_COMPUTE_TYPE = "BUILD_GENERAL1_SMALL"


def enforce_lab_codebuild_compute():
    """Make every CodeBuild CreateProject/UpdateProject call in this kernel use the lab's compute type."""
    import botocore.client

    if getattr(botocore.client.BaseClient, "_lab_codebuild_patch", False):
        return
    original = botocore.client.BaseClient._make_api_call

    def _make_api_call(self, operation_name, api_params):
        if self.meta.service_model.service_name == "codebuild" and operation_name in ("CreateProject", "UpdateProject"):
            env = api_params.get("environment")
            if env and env.get("computeType") != LAB_CODEBUILD_COMPUTE_TYPE:
                api_params = {**api_params, "environment": {**env, "computeType": LAB_CODEBUILD_COMPUTE_TYPE}}
        return original(self, operation_name, api_params)

    botocore.client.BaseClient._make_api_call = _make_api_call
    botocore.client.BaseClient._lab_codebuild_patch = True


def _find_lab_runtimes(client):
    found, token = [], None
    while True:
        kwargs = {"maxResults": 50, **({"nextToken": token} if token else {})}
        resp = client.list_agent_runtimes(**kwargs)
        found += [r for r in resp.get("agentRuntimes", []) if r.get("agentRuntimeName") == AGENT_NAME]
        token = resp.get("nextToken")
        if not token:
            return found


def delete_lab_runtime(region=None, wait=True, timeout=600):
    """Delete the ``personal_finance_agent`` runtime if it exists and wait until it is gone."""
    client = boto3.client("bedrock-agentcore-control", region_name=region or get_region())
    runtimes = _find_lab_runtimes(client)
    for rt in runtimes:
        if rt.get("status") != "DELETING":
            print(f"Deleting existing runtime {rt['agentRuntimeName']} ({rt['agentRuntimeId']}) ...")
            try:
                client.delete_agent_runtime(agentRuntimeId=rt["agentRuntimeId"])
            except ClientError as e:
                if e.response["Error"]["Code"] != "ResourceNotFoundException":
                    raise
    if wait and runtimes:
        deadline = time.time() + timeout
        while _find_lab_runtimes(client):
            if time.time() > deadline:
                raise TimeoutError(f"Runtime {AGENT_NAME} was not deleted within {timeout}s")
            time.sleep(10)
        print(f"Runtime {AGENT_NAME} deleted")


def reset_lab_runtime(region=None):
    """Free the single runtime slot before (re)deploying ``personal_finance_agent``.

    Also removes the local toolkit config, otherwise ``launch()`` would try to *update* the
    previously deployed runtime (UpdateAgentRuntime is not permitted in the lab), and makes the
    toolkit's CodeBuild project use the lab's permitted compute type.
    """
    enforce_lab_codebuild_compute()
    delete_lab_runtime(region)
    cfg = Path(".bedrock_agentcore.yaml")
    if cfg.exists():
        cfg.unlink()
        print("Removed stale .bedrock_agentcore.yaml")


def launch_with_retry(runtime, attempts=4, wait_seconds=30, **launch_kwargs):
    """``runtime.launch(**launch_kwargs)`` with retries when the lab stops the CodeBuild build.

    In the lab account CodeBuild builds are intermittently stopped by an external control
    ("CodeBuild failed with status: STOPPED"); a new build usually succeeds.
    """
    enforce_lab_codebuild_compute()
    for attempt in range(1, attempts + 1):
        try:
            return runtime.launch(**launch_kwargs)
        except RuntimeError as e:
            if "CodeBuild failed with status: STOPPED" not in str(e) or attempt == attempts:
                raise
            print(f"⚠ CodeBuild build was stopped by the lab environment (attempt {attempt}/{attempts}); "
                  f"retrying in {wait_seconds}s ...")
            time.sleep(wait_seconds)


def wait_for_runtime_ready(agent_id, region=None, timeout=900):
    """Poll the runtime and its DEFAULT endpoint until both are READY."""
    client = boto3.client("bedrock-agentcore-control", region_name=region or get_region())
    deadline = time.time() + timeout
    while True:
        status = client.get_agent_runtime(agentRuntimeId=agent_id)["status"]
        if status == "READY":
            try:
                ep = client.get_agent_runtime_endpoint(agentRuntimeId=agent_id, endpointName="DEFAULT")["status"]
            except ClientError:
                ep = "CREATING"
            if ep == "READY":
                return "READY"
        if status.endswith("FAILED"):
            raise RuntimeError(f"Runtime {agent_id} is {status}")
        if time.time() > deadline:
            raise TimeoutError(f"Runtime {agent_id} not READY within {timeout}s (status {status})")
        time.sleep(10)


def recreate_lab_runtime(agent_id, region=None, **overrides):
    """Replace the runtime ``agent_id`` with a new ``personal_finance_agent`` runtime that reuses
    its container image/role/network settings plus ``overrides`` (e.g. ``lifecycleConfiguration``).

    This replaces the UpdateAgentRuntime call / second runtime used by some notebooks, which the
    lab does not allow. Returns an object with ``agent_id``, ``agent_arn`` and ``ecr_uri``.
    """
    from types import SimpleNamespace

    region = region or get_region()
    client = boto3.client("bedrock-agentcore-control", region_name=region)
    current = client.get_agent_runtime(agentRuntimeId=agent_id)
    params = {"agentRuntimeName": AGENT_NAME}
    for key in (
        "agentRuntimeArtifact",
        "roleArn",
        "networkConfiguration",
        "protocolConfiguration",
        "authorizerConfiguration",
        "requestHeaderConfiguration",
        "environmentVariables",
        "lifecycleConfiguration",
    ):
        if current.get(key):
            params[key] = current[key]
    params.update(overrides)
    delete_lab_runtime(region)
    resp = client.create_agent_runtime(**params)
    print(f"Created runtime {AGENT_NAME} ({resp['agentRuntimeId']}), waiting until READY ...")
    wait_for_runtime_ready(resp["agentRuntimeId"], region)
    container = params["agentRuntimeArtifact"].get("containerConfiguration", {}).get("containerUri", "")
    return SimpleNamespace(
        agent_id=resp["agentRuntimeId"], agent_arn=resp["agentRuntimeArn"], ecr_uri=container.split(":")[0]
    )


def stop_runtime_session(agent_arn, session_id, region=None):
    """Stop a runtime session. StopRuntimeSession is not in the lab policy, so an AccessDenied is
    reported instead of raised (the session still ends at its idle timeout or when the runtime is deleted).
    Returns True if the session was stopped."""
    client = boto3.client("bedrock-agentcore", region_name=region or get_region())
    try:
        client.stop_runtime_session(agentRuntimeArn=agent_arn, runtimeSessionId=str(session_id), qualifier="DEFAULT")
        return True
    except ClientError as e:
        if e.response["Error"]["Code"] in ("AccessDeniedException", "AccessDenied"):
            print(
                f"ℹ Lab note: StopRuntimeSession is not permitted in this lab; session {session_id} "
                "ends at its idle timeout or when the runtime is deleted."
            )
            return False
        raise


def invoke_lab_runtime(agent_arn, payload, session_id=None, region=None):
    """Invoke a runtime with SigV4 (IAM) auth and return the decoded response body."""
    import json
    import uuid

    client = boto3.client("bedrock-agentcore", region_name=region or get_region())
    resp = client.invoke_agent_runtime(
        agentRuntimeArn=agent_arn,
        qualifier="DEFAULT",
        runtimeSessionId=session_id or str(uuid.uuid4()),
        payload=json.dumps(payload),
    )
    return resp["response"].read().decode("utf-8")


# --------------------------------------------------------------------------- memory
def _find_lab_memories(client):
    found, token = [], None
    while True:
        kwargs = {"maxResults": 50, **({"nextToken": token} if token else {})}
        resp = client.list_memories(**kwargs)
        found += [m for m in resp.get("memories", []) if m.get("id", "").startswith(f"{MEMORY_NAME}-")]
        token = resp.get("nextToken")
        if not token:
            return found


def delete_lab_memory(region=None, wait=True, timeout=600):
    """Delete the ``FinancialAdvisorMemory`` memory if it exists and wait until it is gone."""
    client = boto3.client("bedrock-agentcore-control", region_name=region or get_region())
    memories = _find_lab_memories(client)
    for m in memories:
        if m.get("status") != "DELETING":
            print(f"Deleting existing memory {m['id']} ...")
            try:
                client.delete_memory(memoryId=m["id"])
            except ClientError as e:
                if e.response["Error"]["Code"] != "ResourceNotFoundException":
                    raise
    if wait and memories:
        deadline = time.time() + timeout
        while _find_lab_memories(client):
            if time.time() > deadline:
                raise TimeoutError(f"Memory {MEMORY_NAME} was not deleted within {timeout}s")
            time.sleep(10)
        print(f"Memory {MEMORY_NAME} deleted")


def reset_lab_memory(region=None):
    """Free the single memory slot so the notebook can create ``FinancialAdvisorMemory`` with its own strategies."""
    delete_lab_memory(region)
